#!/bin/bash
cd ~/Firmware && make posix gazebo

