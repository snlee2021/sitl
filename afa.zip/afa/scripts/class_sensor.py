#!/usr/bin/env python
import numpy as np
import param


class Sensor:
    def __init__(self):
        self.pos_ned_m = np.zeros(3, dtype=float)
        pass

    def callback_local_position_pose(self, data):
        self.pos_ned_m[0] = data.pose.position.y
        self.pos_ned_m[1] = data.pose.position.x
        self.pos_ned_m[2] = data.pose.position.z * (-1.0)
        if param.DEBUG:
            print('pos_ned_m[:] = %.2f %.2f %.2f' % (self.pos_ned_m[0], self.pos_ned_m[1], self.pos_ned_m[2]))
        pass
