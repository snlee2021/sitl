#!/usr/bin/env python
import numpy as np


DEBUG = True

D2R = np.pi / 180.0
R2D = 180.0 / np.pi

CONTROL_HZ = 50.0
