#!/usr/bin/env python
import rospy
import param
import class_sensor
import class_control
from geometry_msgs.msg import PoseStamped


if __name__ == '__main__':
    #
    # Node
    rospy.init_node('afa')
    #
    # Classes
    sensor = class_sensor.Sensor()
    control = class_control.Control(sensor)
    #
    # Subscribe
    rospy.Subscriber('mavros/local_position/pose', PoseStamped, sensor.callback_local_position_pose)
    #
    # Timer
    rospy.Timer(rospy.Duration(1.0 / param.CONTROL_HZ), control.callback_control_main)
    #
    # Spin
    rospy.spin()
    pass
