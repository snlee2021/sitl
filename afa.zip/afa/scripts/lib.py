#!/usr/bin/env python
import numpy as np


def yaw_angle_mod(yaw_angle, unit):
    #
    # Check
    yaw_angle = np.float(yaw_angle)
    #
    # Unit
    if unit == 'rad':
        pi = np.pi
    elif unit == 'deg':
        pi = 180.0
    else:
        return  # NOTE: Error!
    #
    # Main
    while True:
        if yaw_angle > pi:
            yaw_angle -= 2.0 * pi
        elif yaw_angle < -pi:
            yaw_angle += 2.0 * pi
        else:
            return yaw_angle
