#!/usr/bin/env python
import rospy
import param
import lib
from mavros_msgs.msg import PositionTarget


class Control:
    def __init__(self, sensor):
        self.sensor = sensor
        #
        self.msg_setpoint_raw_local = PositionTarget()
        self.pub_setpoint_raw_local = rospy.Publisher('mavros/setpoint_raw/local', PositionTarget, queue_size=10)
        pass

    def pub_cmd(self, north_m, east_m, down_m, psi_deg):
        self.msg_setpoint_raw_local.header.stamp = rospy.Time.now()
        self.msg_setpoint_raw_local.coordinate_frame = self.msg_setpoint_raw_local.FRAME_LOCAL_NED
        self.msg_setpoint_raw_local.type_mask = 0
        self.msg_setpoint_raw_local.type_mask |= (self.msg_setpoint_raw_local.IGNORE_AFX |
                                                  self.msg_setpoint_raw_local.IGNORE_AFY |
                                                  self.msg_setpoint_raw_local.IGNORE_AFZ |
                                                  self.msg_setpoint_raw_local.IGNORE_VX |
                                                  self.msg_setpoint_raw_local.IGNORE_VY |
                                                  self.msg_setpoint_raw_local.IGNORE_VZ |
                                                  self.msg_setpoint_raw_local.IGNORE_YAW_RATE)
        self.msg_setpoint_raw_local.position.x = east_m
        self.msg_setpoint_raw_local.position.y = north_m
        self.msg_setpoint_raw_local.position.z = down_m * (-1.0)
        self.msg_setpoint_raw_local.yaw = lib.yaw_angle_mod(90.0 - psi_deg, 'deg') * param.D2R
        self.pub_setpoint_raw_local.publish(self.msg_setpoint_raw_local)
        pass

    def callback_control_main(self, _):
        self.pub_cmd(5, 5, -5, -45)
        pass
